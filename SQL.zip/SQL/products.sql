-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 10, 2024 at 01:36 AM
-- Server version: 5.5.45
-- PHP Version: 7.0.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `66102010146`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(1, 'Logitech G Pro X Superlight 2', '4590', '1.png'),
(2, 'Logitech G Pro X Superlight', '3990', '2.png'),
(3, 'Logitech g102', '690', '3.png'),
(4, 'Logitech g304', '1190', '4.png'),
(5, 'Logitech G403 Hero', '1390', '5.png'),
(6, 'Logitech G502 Hero RGB', '1490', '6.png'),
(7, 'Logitech G903', '4190', '7.png'),
(8, 'Logitech G705', '3590', '8.png'),
(9, 'Razer DeathAdder V3', '2290', '9.png'),
(10, 'Razer Viper V2 Pro Wireless', '3990', '10.png'),
(11, 'Razer DeathAdder Essential', '690', '11.png'),
(12, 'Razer Basilisk V3 ', '2490', '12.png'),
(13, 'Razer Cobra Pro Wireless', '3490', '13.png'),
(14, 'Razer DeathAdder V3 Pro Wireless', '5690', '14.png'),
(15, 'Razer Orochi V2', '2590', '15.png'),
(16, 'Razer Viper Mini SG Edition', '12500', '16.png'),
(17, 'Razer DeathAdder V3', '2290', '17.png'),
(18, 'EC1 RED V2 (L)', '1700', '18.png'),
(19, 'EC2-CW (M)', '3990', '19.png'),
(20, 'FK1-C (L)', '2190', '20.png'),
(21, 'EC1-CW (L)', '4990', '21.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
